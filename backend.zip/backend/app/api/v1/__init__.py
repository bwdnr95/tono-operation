# backend/app/api/v1/__init__.py

# 패키지 마커 용도만. 실제 router 집합은 api.py 에서 관리.