from __future__ import annotations

import base64
import json
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Sequence

from sqlalchemy import and_, asc, desc, select
from sqlalchemy.orm import Session

from app.domain.models.conversation import (
    BulkSendJob,
    BulkSendJobStatus,
    Conversation,
    ConversationDraftReply,
    ConversationMessageRef,
    ConversationStage,
    ConversationStatus,
    DraftCreatedBy,
    SafetyGuardResult,
    SafetyGuardTarget,
    SafetyStatus,
    SendAction,
    SendActionLog,
    SendActor,
)
from app.domain.models.incoming_message import IncomingMessage


def _encode_cursor(dt: datetime, cid: uuid.UUID) -> str:
    payload = {"dt": dt.isoformat(), "id": str(cid)}
    return base64.urlsafe_b64encode(json.dumps(payload).encode("utf-8")).decode("utf-8")


def _decode_cursor(cursor: str) -> tuple[datetime, uuid.UUID]:
    raw = base64.urlsafe_b64decode(cursor.encode("utf-8")).decode("utf-8")
    obj = json.loads(raw)
    return datetime.fromisoformat(obj["dt"]), uuid.UUID(obj["id"])


def _now_utc() -> datetime:
    return datetime.now(timezone.utc)


def apply_safety_to_conversation(conversation: Conversation, safety_status: SafetyStatus) -> None:
    conversation.safety_status = safety_status
    conversation.stage = ConversationStage.drafted

    if safety_status == SafetyStatus.pass_:
        conversation.status = ConversationStatus.ready_to_send
    elif safety_status == SafetyStatus.review:
        conversation.status = ConversationStatus.needs_review
    else:
        conversation.status = ConversationStatus.blocked


@dataclass
class ConversationSyncService:
    db: Session

    def ensure_conversations_for_property(self, *, property_code: str) -> int:
        """
        incoming_messages (property_code, thread_id) 그룹을 기반으로 conversations / refs를 생성/동기화한다.
        - property_code 없는 메시지는 제외
        - position 은 received_at ASC, id ASC 로 고정
        """
        thread_rows = self.db.execute(
            select(IncomingMessage.thread_id)
            .where(IncomingMessage.property_code == property_code)
            .group_by(IncomingMessage.thread_id)
        ).scalars().all()

        created = 0
        for thread_id in thread_rows:
            conv = self.db.execute(
                select(Conversation).where(
                    and_(Conversation.property_code == property_code, Conversation.thread_id == thread_id)
                )
            ).scalar_one_or_none()

            msgs = self.db.execute(
                select(IncomingMessage)
                .where(and_(IncomingMessage.property_code == property_code, IncomingMessage.thread_id == thread_id))
                .order_by(asc(IncomingMessage.received_at), asc(IncomingMessage.id))
            ).scalars().all()
            if not msgs:
                continue

            last_msg = msgs[-1]
            last_at = last_msg.received_at
            last_id = last_msg.id
            ota = last_msg.ota

            if conv is None:
                conv = Conversation(
                    property_code=property_code,
                    ota=ota,
                    thread_id=thread_id,
                    last_message_at=last_at,
                    last_message_id=last_id,
                    status=ConversationStatus.open,
                    safety_status=SafetyStatus.pass_,
                    stage=ConversationStage.intake,
                )
                self.db.add(conv)
                self.db.flush()
                created += 1
            else:
                conv.ota = ota
                conv.last_message_at = last_at
                conv.last_message_id = last_id
                conv.updated_at = _now_utc()

            existing = self.db.execute(
                select(ConversationMessageRef.message_id, ConversationMessageRef.position).where(
                    ConversationMessageRef.conversation_id == conv.id
                )
            ).all()
            existing_map = {row[0]: row[1] for row in existing}

            for idx, m in enumerate(msgs, start=1):
                if m.id in existing_map:
                    continue
                self.db.add(
                    ConversationMessageRef(
                        conversation_id=conv.id,
                        message_id=m.id,
                        position=idx,
                    )
                )

        self.db.commit()
        return created


@dataclass
class SafetyGuardService:
    db: Session

    def evaluate_text(self, *, conversation_id: uuid.UUID, target: SafetyGuardTarget, text: str) -> SafetyGuardResult:
        """
        보수적 휴리스틱 Safety Guard.
        - block: 폭력/자해/무기/불법/결제정보 요구 등
        - review: 개인정보/연락처/주소/계좌 등 가능성
        - pass: 그 외
        """
        lower = (text or "").lower()

        reason_codes: list[str] = []
        status = SafetyStatus.pass_
        notes: str | None = None

        block_keywords = [
            "suicide",
            "self-harm",
            "kill",
            "weapon",
            "gun",
            "bomb",
            "illegal",
            "drugs",
            "credit card",
            "card number",
            "cvv",
            "wire transfer",
            "bank account",
            "passport",
            "ssn",
        ]
        review_keywords = [
            "phone",
            "kakao",
            "whatsapp",
            "wechat",
            "email",
            "address",
            "account number",
            "routing",
            "id number",
            "passport",
        ]

        if any(k in lower for k in block_keywords):
            status = SafetyStatus.block
            reason_codes.append("sensitive_or_illegal")
            notes = "Detected high-risk keyword(s)."
        elif any(k in lower for k in review_keywords):
            status = SafetyStatus.review
            reason_codes.append("pii_or_contact_exchange")
            notes = "Possible PII/contact exchange."

        sgr = SafetyGuardResult(
            conversation_id=conversation_id,
            target=target,
            status=status,
            reason_codes=reason_codes,
            notes=notes,
        )
        self.db.add(sgr)
        self.db.flush()
        return sgr


@dataclass
class ConversationDraftService:
    db: Session

    def _build_prompt(self, *, messages: Sequence[IncomingMessage], summary_text: str | None) -> str:
        parts: list[str] = []
        if summary_text:
            parts.append(f"[Conversation Summary]\n{summary_text}\n")
        parts.append("[Messages]")
        for m in messages[-12:]:
            who = m.sender_actor.value if hasattr(m.sender_actor, "value") else str(m.sender_actor)
            body = m.pure_guest_message or ""
            parts.append(f"- {who}: {body}".strip())
        parts.append("\n[Instruction]\nWrite a helpful host reply in Korean. Be concise and polite.")
        return "\n".join(parts).strip()

    def generate_llm_draft(self, *, conversation: Conversation) -> str:
        """
        Conversation 구조 입력 기반으로 초안 생성.
        (LLM 교체 가능: draft 생성은 Conversation 구조에 귀속)
        """
        msgs = self.db.execute(
            select(IncomingMessage)
            .join(ConversationMessageRef, ConversationMessageRef.message_id == IncomingMessage.id)
            .where(ConversationMessageRef.conversation_id == conversation.id)
            .order_by(asc(ConversationMessageRef.position))
        ).scalars().all()

        last_guest = None
        for m in reversed(msgs):
            val = getattr(m.sender_actor, "value", None) or str(m.sender_actor)
            val = val.split(".")[-1]
            if val == "GUEST":
                last_guest = m
                break

        if last_guest and (last_guest.pure_guest_message or "").strip():
            guest_text = (last_guest.pure_guest_message or "").strip()
            return (
                f'안녕하세요! 문의 주셔서 감사합니다. 말씀하신 내용("{guest_text[:120]}") 확인했습니다. '
                "추가로 필요한 정보가 있으면 알려주시면 바로 도와드리겠습니다."
            )
        return "안녕하세요! 문의 주셔서 감사합니다. 내용을 확인하고 안내드리겠습니다."

    def upsert_draft(
        self,
        *,
        conversation: Conversation,
        content: str,
        created_by: DraftCreatedBy,
        safety_status: SafetyStatus,
    ) -> ConversationDraftReply:
        draft = self.db.execute(
            select(ConversationDraftReply)
            .where(ConversationDraftReply.conversation_id == conversation.id)
            .order_by(desc(ConversationDraftReply.created_at))
            .limit(1)
        ).scalar_one_or_none()

        if draft is None:
            draft = ConversationDraftReply(
                conversation_id=conversation.id,
                content=content,
                created_by=created_by,
                safety_status=safety_status,
            )
            self.db.add(draft)
            self.db.flush()
            return draft

        draft.content = content
        draft.created_by = created_by
        draft.safety_status = safety_status
        draft.updated_at = _now_utc()
        self.db.add(draft)
        self.db.flush()
        return draft


@dataclass
class SendLogService:
    db: Session

    def log(
        self,
        *,
        property_code: str,
        actor: SendActor,
        action: SendAction,
        conversation_id: uuid.UUID | None = None,
        bulk_send_job_id: uuid.UUID | None = None,
        message_id: uuid.UUID | None = None,
        payload: dict | None = None,
    ) -> SendActionLog:
        rec = SendActionLog(
            property_code=property_code,
            actor=actor,
            action=action,
            conversation_id=conversation_id,
            bulk_send_job_id=bulk_send_job_id,
            message_id=message_id,
            payload_json=payload or {},
        )
        self.db.add(rec)
        self.db.flush()
        return rec


def make_confirm_token() -> str:
    return uuid.uuid4().hex
